from selenium import webdriver
from selenium.webdriver.common.by import By

def web_driver():
    import csv
    import time
    options = webdriver.FirefoxOptions()
    options.add_argument("--verbose")
    options.add_argument('--no-sandbox')
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    options.add_argument("--window-size=1920, 1200")
    options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Firefox(options=options)
    return driver

import csv
import time
driver = web_driver()
def isi_otomatis():
    with open('Book74.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=';')
        for ari in csv_reader:

            driver.get('https://auth.alchemy.com/?redirectUrl=https%3A%2F%2Fdashboard.alchemy.com%2Fsignup%3Fa%3Darbitrum_faucet%26redirectUrl%3Dhttps%253A%252F%252Fwww.alchemy.com%252Ffaucets%252Farbitrum-sepolia%253FauthRefresh%253DTrue%26attempt%3D1')
            time.sleep(2)

            time.sleep(2)
            Email = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/form/label[1]/input')
            Email.send_keys(ari[0])

            time.sleep(1)
            Password = driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/form/label[2]/input')
            Password.send_keys(ari[1])

            time.sleep(1)
            driver.find_element(by=By.XPATH, value='/html/body/div[1]/div[1]/div/div[1]/div[2]/div/div[2]/form/button').click()
            ########################################################################################################################
            #ARBITRUM
            time.sleep(20)
            Address = driver.find_element(by=By.XPATH, value='/html/body/div/div[1]/div[2]/div[2]/div[2]/div/span/form/div/div[1]/input')
            Address.send_keys(ari[2])

            time.sleep(1)
            driver.find_element(by=By.XPATH, value='/html/body/div/div[1]/div[2]/div[2]/div[2]/div/span/form/div/div[2]/button/div/span').click()
            time.sleep(5)

            time.sleep(1)
            driver.get('https://auth.alchemy.com/logout/?immediate=true&redirectUrl=https%3A%2F%2Fwww.alchemy.com%2Ffaucets%2Farbitrum-sepolia')
            time.sleep(5)

isi_otomatis()